package com.markubiadas.caranddriver;

public class Car {

	// Attributes
	public int gas = 10;
	
	
	


	// Display gas level
	public void gasLevel() {
		System.out.println("Gas level is: " + gas+ "/10");
	}
	
}
