package com.markubiadas.caranddriver;

public class CarAndDriverTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver driver1 = new Driver();
		
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		

	}

}
