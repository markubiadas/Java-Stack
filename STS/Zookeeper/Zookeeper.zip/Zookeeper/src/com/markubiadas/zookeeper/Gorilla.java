package com.markubiadas.zookeeper;

public class Gorilla extends Mammal{
	
	public Gorilla() {
		this.energyLevel = energyLevel;
	}

	// Methods
	// 1. Throw
	public void throwThings() {
		System.out.println("Gorilla throws a thing.");
		this.energyLevel -= 5;
		this.displayEnergyLevel();
	}
	
	// 2. Eat Bananas
	public void eatBananas() {
		System.out.println("Gorilla eats bananas.");
		this.energyLevel += 10;
		this.displayEnergyLevel();
	}
	
	// 3. Climb
	public void climb() {
		System.out.println("Gorilla climbs up.");
		this.energyLevel -= 10;
		this.displayEnergyLevel();
	}
	
	
	
	
	
	
	
	//	Display Energy
//	public int displayEnergyLevel() {
//		super.displayEnergyLevel();
//		return energyLevel;
//	}
}
