package com.markubiadas.zookeeper;

public class Mammal {

	//Attributes
	public int energyLevel = 100;
	
	
	//Display Energy
	public int displayEnergyLevel(){
		System.out.println("Energy level is: " + energyLevel);
		return energyLevel;
	}
	
}
